-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: ec2-43-203-200-59.ap-northeast-2.compute.amazonaws.com    Database: user
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_id` varchar(255) NOT NULL,
  `join_date` datetime(6) NOT NULL,
  `nickname` varchar(15) NOT NULL,
  `profile_image` varchar(255) DEFAULT NULL,
  `role` enum('ROLE_USER','ROLE_ADMIN') NOT NULL DEFAULT 'ROLE_USER',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES ('3448548097','2024-05-13 21:26:23.287735','김신영','http://t1.kakaocdn.net/account_images/default_profile.jpeg.twg.thumb.R640x640','ROLE_USER'),('3452659543','2024-05-13 21:18:39.797776','박태호',NULL,'ROLE_USER'),('3452992819','2024-05-13 23:05:58.282042','이현호','http://k.kakaocdn.net/dn/hQA8L/btr0BClPKjh/YgcBWlcOYigokCVkCLO6pK/img_640x640.jpg','ROLE_USER'),('3458607590','2024-05-13 22:10:49.225581','강민지','http://t1.kakaocdn.net/account_images/default_profile.jpeg.twg.thumb.R640x640','ROLE_USER'),('3460091535','2024-05-13 22:01:02.613464','김지연','http://k.kakaocdn.net/dn/yUVv6/btsE0hgI67b/xdJ5ax58CQoCAmkvnHZaN1/img_640x640.jpg','ROLE_USER'),('3463207627','2024-05-13 21:40:00.275178','승재홍','http://t1.kakaocdn.net/account_images/default_profile.jpeg.twg.thumb.R640x640','ROLE_USER'),('3480607171','2024-05-13 22:15:57.089525','이민규',NULL,'ROLE_USER'),('3480611809','2024-05-13 22:18:58.487800','서정빈',NULL,'ROLE_USER'),('3480612908','2024-05-13 22:19:40.766997','송아람','http://t1.kakaocdn.net/account_images/default_profile.jpeg.twg.thumb.R640x640','ROLE_USER'),('3481057949','2024-05-14 10:04:07.354913','김지현',NULL,'ROLE_USER'),('3481058926','2024-05-14 10:04:50.510584','강찬우','http://k.kakaocdn.net/dn/lpa8T/btsB3c3f2qR/sVAcf03nEa4X3HQZDyUhd1/img_640x640.jpg','ROLE_USER'),('3481060329','2024-05-14 10:05:50.364685','한재현',NULL,'ROLE_USER'),('3481061445','2024-05-14 10:06:36.878006','허승경',NULL,'ROLE_USER'),('3481062506','2024-05-14 10:07:21.518442','문신웅',NULL,'ROLE_USER'),('3481062640','2024-05-14 10:07:27.335636','정태윤',NULL,'ROLE_USER'),('3481065784','2024-05-14 10:09:39.060327','장승호','http://k.kakaocdn.net/dn/bT02uH/btqZQajcota/ZRn7dpYbKjXhx7bGvGFA91/img_640x640.jpg','ROLE_USER'),('3481072070','2024-05-14 10:14:07.222230','이현석','http://k.kakaocdn.net/dn/0Q62k/btsk82YijGA/AgYGSbS39grZwFTkokJIFK/img_640x640.jpg','ROLE_USER'),('3481082777','2024-05-14 10:22:02.114438','임승연',NULL,'ROLE_USER'),('3481118008','2024-05-14 10:47:43.607674','김소영',NULL,'ROLE_USER'),('3481119733','2024-05-14 10:48:54.749130','배상훈','http://k.kakaocdn.net/dn/cnJQeO/btrWr6YDNnE/BosYEMm1171lBWU4DWKmmk/img_640x640.jpg','ROLE_USER'),('3481124765','2024-05-14 10:52:28.626157','한기철','http://k.kakaocdn.net/dn/czMOdK/btrHn0REJz6/zYDWOKpO2ilLpjTyKV9iB0/img_640x640.jpg','ROLE_USER'),('3481142028','2024-05-14 11:04:33.005722','박정훈',NULL,'ROLE_USER'),('3481160970','2024-05-14 11:17:39.946413','김현지',NULL,'ROLE_USER'),('3481171806','2024-05-14 11:25:19.104998','문철환','http://k.kakaocdn.net/dn/be4Qsi/btsHnjw5PeG/7tcKAVELB4nvue76bXt9D0/m1.jpg','ROLE_USER'),('3481228692','2024-05-14 12:06:40.697605','규훈','http://t1.kakaocdn.net/account_images/default_profile.jpeg.twg.thumb.R640x640','ROLE_USER'),('3481276130','2024-05-14 12:37:38.883914','정종욱','http://t1.kakaocdn.net/account_images/default_profile.jpeg.twg.thumb.R640x640','ROLE_USER'),('3481301375','2024-05-14 12:53:56.481536','김민성',NULL,'ROLE_USER'),('3481347908','2024-05-14 13:22:33.600080','유세진','http://k.kakaocdn.net/dn/b4gtOn/btsEKHfiK7k/Vw2qRj0Gzguu2pcWHU1vpk/img_640x640.jpg','ROLE_USER'),('3481482173','2024-05-14 14:50:22.068560','L.HJ','http://k.kakaocdn.net/dn/2B3Jb/btrfKASGCLp/Gff8xoyTtgq2Dc5GKJDhC1/img_640x640.jpg','ROLE_USER'),('3481489158','2024-05-14 14:55:00.401967','뉸찌?','http://t1.kakaocdn.net/account_images/default_profile.jpeg.twg.thumb.R640x640','ROLE_USER'),('3481709844','2024-05-14 17:25:27.705253','여진구','http://k.kakaocdn.net/dn/cyAguV/btsGevycz9Z/oqws4yKqPUIdGj7ljAe461/img_640x640.jpg','ROLE_USER'),('3481974650','2024-05-14 20:47:01.285926','최시은',NULL,'ROLE_USER'),('3483624991','2024-05-15 22:55:57.868089','승수근','http://k.kakaocdn.net/dn/V3ySt/btqHoqY1rez/E5hyNb2yufkm7j9yh3BIb1/img_640x640.jpg','ROLE_USER'),('3483632331','2024-05-15 23:01:47.793561','승규',NULL,'ROLE_USER'),('3484031592','2024-05-16 10:25:24.178577','김도휘',NULL,'ROLE_USER'),('3484261321','2024-05-16 13:09:19.654777','전승혜',NULL,'ROLE_USER'),('3484937674','2024-05-16 21:03:29.959416','고예은',NULL,'ROLE_USER'),('3484992289','2024-05-16 21:43:00.201798','강채연',NULL,'ROLE_USER'),('3485374985','2024-05-17 08:34:09.460273','자영',NULL,'ROLE_USER'),('3485603061','2024-05-17 11:34:33.314103','승호','http://k.kakaocdn.net/dn/do7t2f/btszKb7TcLD/UQ1Yvsod2AOjYnxYzkFZHk/img_640x640.jpg','ROLE_USER'),('3486098127','2024-05-17 17:24:17.227403','전원빈',NULL,'ROLE_USER');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-20  9:09:07
