-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: k10c107.p.ssafy.io    Database: funding
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sponsor`
--

DROP TABLE IF EXISTS `sponsor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sponsor` (
  `sponsor_id` int NOT NULL AUTO_INCREMENT,
  `amount` int DEFAULT NULL,
  `comment` varchar(50) DEFAULT NULL,
  `join_time` datetime(6) DEFAULT NULL,
  `nickname` varchar(15) DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `funding_id` int DEFAULT NULL,
  `transaction_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`sponsor_id`),
  UNIQUE KEY `UK_a4wmhc7qx8s8cnpvcki7jp91y` (`transaction_id`),
  KEY `FK4qj9do4abjgqrruk64rnty9a` (`funding_id`),
  CONSTRAINT `FK4qj9do4abjgqrruk64rnty9a` FOREIGN KEY (`funding_id`) REFERENCES `funding` (`funding_id`),
  CONSTRAINT `FK59opq2rxeex027bywct9y6fm4` FOREIGN KEY (`transaction_id`) REFERENCES `transaction` (`transaction_id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sponsor`
--

LOCK TABLES `sponsor` WRITE;
/*!40000 ALTER TABLE `sponsor` DISABLE KEYS */;
INSERT INTO `sponsor` VALUES (1,50000,'생일 축하해요!!','2024-05-13 21:40:43.703258','이현호','3452992819',3,'chuka_1715604015080'),(2,50000,'생일 미리 축하해~~~~~~~','2024-05-13 21:42:24.280496','신영','3448548097',3,'chuka_1715604043139'),(3,10000,'겸둥이 생축','2024-05-13 21:47:45.808042','사랑아신영해',NULL,1,'chuka_1715604448048'),(4,10000,'신영이 기여어','2024-05-13 21:52:55.008534','사막여우','3460091535',1,'chuka_1715604759326'),(5,5000,'작은 금액이나마 보태봅니다 ㅎㅎ','2024-05-13 22:38:57.207702','내가누구게',NULL,7,'chuka_1715607515946'),(6,200000,'축의금 대신 드립니다','2024-05-13 23:10:40.092490','내꿈은건물주','3458607590',7,'chuka_1715609402526'),(7,1000,'정성을 담아봅니다\n축하드려요! ','2024-05-14 11:28:39.587782','녹쌕','3481124765',10,'chuka_1715653647639'),(8,50000,'성공기원','2024-05-14 11:37:16.546000','이싸피','3452659543',11,'chuka_1715654220720'),(9,50000,'당신의 성공을 응원합니다','2024-05-14 11:38:18.761737','오싸피','3452659543',11,'chuka_1715654285259'),(10,50000,'화이팅','2024-05-14 11:39:15.804587','나싸피','3452659543',11,'chuka_1715654336586'),(11,50000,'성 공 ','2024-05-14 11:40:01.788233','김싸피','3452659543',11,'chuka_1715654379930'),(12,50000,'보잘 것 없지만 보탬이 되고 싶습니다. 컨설턴트님','2024-05-14 15:10:09.976529','이현호','3452992819',9,'chuka_1715666979885'),(13,1000,'','2024-05-14 15:10:54.647164','test','3480607171',12,'chuka_1715667038357'),(14,1000000,'','2024-05-14 15:12:11.092968','','3480607171',12,'chuka_1715667118956'),(15,100000,'','2024-05-14 15:12:16.193189','하하','3480611809',9,'chuka_1715667114631'),(16,1000000,'결혼 축하합니다!!','2024-05-14 15:14:32.783201','민규','3480607171',7,'chuka_1715667260736'),(17,490000,'ㅋㅋ','2024-05-14 17:11:47.989007','','3458607590',13,'chuka_1715674272164'),(18,300000,'항상 감사합니다','2024-05-16 10:13:57.058251','레서판다','3460091535',9,'chuka_1715822006341'),(19,20000000,'축하합니다 !','2024-05-16 12:19:57.947667','익명',NULL,14,'chuka_1715829542995'),(20,77590,'오늘은 내가 쏜다','2024-05-16 13:55:42.888535','이현호','3452992819',5,'chuka_1715835297490'),(21,1000,'축하합니다 !','2024-05-16 13:59:33.411942','익명','3458607590',14,'chuka_1715835542166'),(22,1000,'축하합니다 !','2024-05-16 14:22:57.287784','익명','3481060329',1,'chuka_1715836959683'),(23,20000,'축하합니다 !','2024-05-16 16:55:24.775228','익명','3452659543',16,'chuka_1715846087984'),(24,1000,'100원은 아쉬우니 1000원! 기분이다!','2024-05-16 17:29:43.613886','익명','3448548097',15,'chuka_1715848153012'),(25,20000,'축하합니다 !','2024-05-17 12:16:13.122290','파인트','3463207627',17,'chuka_1715915748363'),(26,10000,'이정도는 축하해애지','2024-05-17 13:29:34.675880','갑부','3458607590',15,'chuka_1715920159069'),(27,20000,'이 금액이 보탬이 되었으면 좋겠습니다','2024-05-17 17:05:32.485388','승재홍','3463207627',18,'chuka_1715933097095');
/*!40000 ALTER TABLE `sponsor` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-17 20:10:33
