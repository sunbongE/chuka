-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: k10c107.p.ssafy.io    Database: funding
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `funding`
--

DROP TABLE IF EXISTS `funding`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `funding` (
  `funding_id` int NOT NULL AUTO_INCREMENT,
  `address` varchar(150) DEFAULT NULL,
  `address_detail` varchar(150) DEFAULT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `event_id` int DEFAULT NULL,
  `goal_amount` int DEFAULT NULL,
  `introduce` varchar(50) DEFAULT NULL,
  `option` varchar(50) DEFAULT NULL,
  `postal_code` varchar(50) DEFAULT NULL,
  `product_image` varchar(255) DEFAULT NULL,
  `product_link` varchar(2048) DEFAULT NULL,
  `product_name` varchar(255) DEFAULT NULL,
  `product_price` int DEFAULT NULL,
  `receiver_name` varchar(20) DEFAULT NULL,
  `receiver_phone` varchar(90) DEFAULT NULL,
  `result` enum('ONGOING','SUCCESS','COMPLETE') DEFAULT 'ONGOING',
  `status` enum('PENDING','APPROVE','REJECT','STOP') DEFAULT 'PENDING',
  `user_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`funding_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `funding`
--

LOCK TABLES `funding` WRITE;
/*!40000 ALTER TABLE `funding` DISABLE KEYS */;
INSERT INTO `funding` VALUES (1,'XMZ+zOiCE6C+HQ1OGZFCpfdgyo10twDJ3UiP5NfdKPY=','UdxJy0w1CZz012KtbMgbRg==','2024-05-13 21:37:05.388563','2024-05-20',3,48360,'귀염둥이 신영이 탄신일','','Dqv11kDGp6eXemJ238RMvg==','https://cdn.011st.com/11dims/resize/600x600/quality/75/11src/product/5969755632/B.jpg?740000000','https://www.11st.co.kr/products/5969755632?&trTypeCd=PW24&trCtgrNo=585021','시크릿쥬쥬 고양이 인형 장난감 역할 놀이 여아',48360,'김신영','4LTEzQWduyghsy+dNn01gQ==','ONGOING','APPROVE','3452992819'),(2,'j++WbXl/Pbvvg0+RrYI4zjmuS71Y66Z+SuN/rMmvlEGR07DE23fusn6ir5OhqIdX','umIAwp66DS6YTBZqxbHr2Q==','2024-05-13 21:37:49.242625','2024-10-31',1,5900,'할로윈호박바구니','할로윈호박바구니(소)(12개) 할로윈 사탕 선물 바구니','ciYSZ2NQUb9SKV8eFPZZuw==','https://cdn.011st.com/11dims/resize/600x600/quality/75/11src/product/6367352444/B.jpg?457000000','https://www.11st.co.kr/products/6367352444','할로윈호박바구니 할로윈 사탕 선물 바구니',5900,'박태호','PbhXYJ450VITDb8DAN47EA==','ONGOING','APPROVE','3452659543'),(3,'XMZ+zOiCE6C+HQ1OGZFCpTcH3sNBS9Hvvrpmmrd18Ag=','PO+3RzWRuUP6d3XwwDEc0A==','2024-05-13 21:39:20.358410','2024-07-14',2,555000,'건강한 코딩생활을위해','화이트 색상','lZ4rZtGgTmB6sE00+wJcXA==','https://shop-phinf.pstatic.net/20230504_90/1683185017578awe0m_JPEG/202305041622420.jpg?type=m510','https://brand.naver.com/desker/products/7638162748?NaPm=ct%3Dlvpjn128|ci%3D3addf1eb8f5f1f358179af3de5d4aedee4a65248|tr%3Dnshfu|sn%3D686999|hk%3D0172afa8d17f5c39ef5bb55c5ecd2bb2b371713c','데스커 DSDCM1607M 모션데스크 플러스 이동형 1600x700',660000,'김지연','7WN9DkfRlah69nfGnGad+Q==','ONGOING','APPROVE','3448548097'),(4,'F2rhoG2EJFMRSPRbjm2aOGV4+QANNsz8Em6IaXZafVI=','+UGhxG6utT7Q3pRZUxByAQ==','2024-05-13 21:43:05.931383','2024-12-25',4,125000,'크리스마스트리','무장식 대형트리 PE 알프스트리 150cm ','hwysiI7i5GE1Lu2ZvstpWw==','https://shop-phinf.pstatic.net/20231205_191/1701766527476NAXCL_JPEG/102902416176562847_2111405798.jpg?type=m510','https://smartstore.naver.com/flowertree/products/4708854681?NaPm=ct%3Dlw4x38o0%7Cci%3D302a48628dac570539ee0b1ac07231ca296f12ae%7Ctr%3Dslsl%7Csn%3D340977%7Chk%3D7ca386ee3b5768af13c33161015546568aadb1f4','크리스마스트리 무장식 대형트리 PE 알프스트리 150cm',785000,'박태호','PbhXYJ450VITDb8DAN47EA==','ONGOING','APPROVE','3452659543'),(5,'XMZ+zOiCE6C+HQ1OGZFCpfdgyo10twDJ3UiP5NfdKPY=','hNyaHkGQiQUtlOLV2p29rA==','2024-05-13 21:44:38.200558','2024-05-20',3,77590,'생일 축하해!','GOLS 컨투어H','Dqv11kDGp6eXemJ238RMvg==','https://gdimg.gmarket.co.kr/2231196817/still/600?ver=1715507204','https://item.gmarket.co.kr/Item?goodscode=2231196817&buyboxtype=ad','GOLS 오가닉 라텍스 베개 기능성 경추 숙면 목이편한',77590,'김신영','EKjCJAUXDefgLP2OfGupBQ==','SUCCESS','APPROVE','3452992819'),(7,'bZ+hFCGW9UP784w++5ROx2i8PTGUeT2ijT6+z6O9uj1pxJNZ+3OhUPVAJPP4v0bZq5EJH6m6g/Do\n51gJwHMQ0Q==','PO+3RzWRuUP6d3XwwDEc0A==','2024-05-13 22:10:05.877282','2024-07-30',7,773120,'혼수','','ZI5H1SGbGfV2xiThw9f4wA==','https://image.auction.co.kr/itemimage/42/8a/c9/428ac9b0a6.jpg','http://itempage3.auction.co.kr/DetailView.aspx?ItemNo=C361230144&frm3=V2','비스포크 DW60A8355FG 식기세척기 열풍건조 12인용 리폼비 지원 빌트인겸용',773120,'승재홍','7WN9DkfRlah69nfGnGad+Q==','SUCCESS','APPROVE','3448548097'),(9,'XMZ+zOiCE6C+HQ1OGZFCpVXa7AKPdUoVI7rFzS8FUpQ877dHNZG5Q/p3dfDAMRzQ','PO+3RzWRuUP6d3XwwDEc0A==','2024-05-13 22:53:48.475365','2024-05-15',6,645920,'플스하자','','8abTEy1/1C3SUsGp7tJa9Q==','https://cdn.011st.com/11dims/resize/600x600/quality/75/11src/product/6748352725/B.jpg?210000000','https://www.11st.co.kr/products/6748352725?NaPm=ct%3Dlw4zjwso%7Cci%3Dc8fe317ae185e638797592c682dae3489f941ef2%7Ctr%3Dslbrc%7Csn%3D17703%7Chk%3Ddc9a9df8b763fc7a099ae11a6460d105bc7df692&utm_term=&utm_campaign=%B3%D7%C0%CC%B9%F6pc_%B0%A1%B0%DD%BA%F1%B1%B3%B1%E2%BA%BB&utm_source=%B3%D7%C0%CC%B9%F6_PC_PCS&utm_medium=%B0%A1%B0%DD%BA%F1%B1%B3','소니 플레이스테이션5 슬림 1TB 디스크 에디션 PS5 CFI-2018 / 오늘출발 GC',729000,'한기철','7WN9DkfRlah69nfGnGad+Q==','COMPLETE','APPROVE','3448548097'),(10,'Ka+nxTB71HVDlIYymgx2ktd1mO5rdFWPr/IqtmZOhM7Ei/y1L1yfzaVXRissadwG','uFFKpCJ3f4+o8/nHeQo0bg==','2024-05-14 11:24:53.826230','2024-05-31',26,1000000,'조여사님의 73번째 생신을 맞아 준비합시다!','갤럭시 Z플립5 256G','vqDSzGtWj8Si2U/Xf202jA==','https://cdn.011st.com/11dims/resize/600x600/quality/75/11src/product/7087620856/B.png?565000000','https://www.11st.co.kr/products/7087620856?NaPm=ct%3Dlw5rq0ig%7Cci%3D44bb96e39ba2ec5daaab0ace99cea5b7326d1a2e%7Ctr%3Dslsbrc%7Csn%3D17703%7Chk%3D47af6ea8269daead006638bb419a27cf76f9f36d&utm_term=&utm_campaign=%B3%D7%C0%CC%B9%F6pc_%B0%A1%B0%DD%BA%F1%B1%B3%B1%E2%BA%BB&utm_source=%B3%D7%C0%CC%B9%F6_PC_PCS&utm_medium=%B0%A1%B0%DD%BA%F1%B1%B3','SM-F731N 삼성전자 갤럭시 Z플립5 자급제 5G 256GB 그라파이트 오늘출발',1180980,'양미영','m6e/CqT/pDDkmIVT7AYqKg==','ONGOING','APPROVE','3481124765'),(11,'HJoG9ipAWmy3H0UP/WIOS5TxO2qpS6io5ZIuw+bgnzuGv8dQv6C1QaAOzUN7XxOM','+UGhxG6utT7Q3pRZUxByAQ==','2024-05-14 11:31:14.455366','2024-10-31',20,200000,'성공기원 선물','모두 기본으로 해주세요.','WAgsL4KZbQ5YgjjAq6bmNg==','https://cdn.011st.com/11dims/resize/600x600/quality/75/11src/product/6736249766/B.jpg?127000000','https://www.11st.co.kr/products/6736249766','갤럭시 자급제 SM-S928N 5G/LTE 유심호환',1698400,'박싸피','RB2t4vVC83cR5/m1fty3aw==','SUCCESS','APPROVE','3452659543'),(12,'Ka+nxTB71HVDlIYymgx2kg5hpaCQ/L37Y+QVj3zQZlA=','5/0SFo1sYCgQeGMHnCL35w==','2024-05-14 13:27:07.777996','2024-06-18',34,500000,'침대 ㄱㄱ','흰색 1개','f4ZTg8i7T3+oaKaavv++Gg==','https://shop-phinf.pstatic.net/20230922_155/1695346956656aL2Kq_JPEG/2633435473593002_191238468.jpg?type=m510','https://smartstore.naver.com/inbesco/products/5579574455?n_media=11068&n_query=%EC%B9%A8%EB%8C%80&n_rank=3&n_ad_group=grp-a001-02-000000009017166&n_ad=nad-a001-02-000000147501301&n_campaign_type=2&n_mall_id=inbesco&n_mall_pid=5579574455&n_ad_group_type=2&n_match=3&NaPm=ct%3Dlw5w4fg0%7Cci%3D0yy0003sTO9AoeFKDvnP%7Ctr%3Dpla%7Chk%3D980d2408e73d5be05500dc8c0473579ee83389f1','인베스코 가죽 LED 퀸사이즈 침대세트 유로탑 매트리스',699900,'유세진','+7q8SAFZvRAbcuoWbHSH3A==','SUCCESS','APPROVE','3481347908'),(13,'XMZ+zOiCE6C+HQ1OGZFCpTFcsd1nPRVnpwBQlCOtS3w8mR5d/TnKaPM1tgcSyCH6','/tUefItGgaBGiQcFT/59kg==','2024-05-14 14:13:11.928073','2024-07-01',29,481290,'손에 물묻히지 않고 살아가는 방법','','1lWrCsGCuPYC3CElLrU1wA==','https://image.auction.co.kr/itemimage/3d/11/6f/3d116f3096.jpg','http://itempage3.auction.co.kr/DetailView.aspx?ItemNo=C411994486&frm3=V2','6인용 비스포크 식기세척기 DW30A3030CE 공식파트너',550000,'강민지','WiNValzm2xsqgnH71X9F2w==','SUCCESS','APPROVE','3458607590'),(14,'Ij52cHJ8/8EK7/f2d+U7ECsGDyc7/g8rsK/KjR9p+J3Sjc3EX/2Lbc5lPNppT8uC','eaIqNKS2w3TmTxbXDj0R3A==','2024-05-16 12:17:01.252962','2024-05-18',36,20000000,'제발 사주세요','512GB','WWv+WkZmKYdHHO07HqlYUg==',NULL,'https://www.samsung.com/sec/event/galaxy-tabs9-series/',NULL,NULL,'zz','39VWR0+vvs5UCmPW3wOpLQ==','SUCCESS','REJECT','3458607590'),(15,'XMZ+zOiCE6C+HQ1OGZFCpXBjIMRWPxhdhrAKasVbG7kM1DYBzNufN5homLb6DmeR','++D6PTLqp95Q3p2LC9mUWQ==','2024-05-16 13:30:02.678606','2024-05-24',41,26900,'100원씩받아서마우스사기(1/269)','화이트','1d7h1JVjkUrArY5UeCLvNA==','https://cdn.011st.com/11dims/resize/600x600/quality/75/11src/pd/v2/2/7/0/1/3/2/MJPeg/6410270132_B.jpg','https://www.11st.co.kr/products/6410270132?&trTypeCd=PW00&trCtgrNo=585021&checkCtlgPrd=true','버티컬 블루투스 무선마우스 NG09',26900,'전승혜','KvZB3UbXtTq+yHyMl1Rtjg==','ONGOING','APPROVE','3484261321'),(16,'3LjRcZg5QCwBQu1WKKgCKDdvgtCEzCqo+yVCU/fscpo877dHNZG5Q/p3dfDAMRzQ','8Jcc6cMiFhjejA18NA0wug==','2024-05-16 14:30:21.241976','2024-05-12',20,5900,'성공기원 선물','모두 기본으로 해주세요.','yQeuE8GH2ZPL2WivDY8AtA==',NULL,'s',NULL,NULL,'박태호','5qZHYQRasAGjAXuhr0tAfw==','SUCCESS','REJECT','3452659543'),(17,'XMZ+zOiCE6C+HQ1OGZFCpZktPDysGvhPMgTOaZf4dW5YSY8c/rUeRSAK54tl5hml','kjsT+jBJ0ULLDpHUK1Q/LTzvt0c1kblD+nd18MAxHNA=','2024-05-16 22:27:51.072773','2024-05-26',43,650000,'구민아 사랑한데이','흰색','RqkVsCgSs00xIzPMUaLbhw==',NULL,'https://msearch.shopping.naver.com/catalog/44773880618?NaPm=ct%3Dlw9a349c%7Cci%3D49adf47e42b844f975e13ec44100a1137b8f6178%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D7595651d70e73c9bfc43fff17c41641d2061d21c&deliveryCharge=true&isOfficialOrCerti=false&query=%ED%94%8C%EB%A0%88%EC%9D%B4%EC%8A%A4%ED%85%8C%EC%9D%B4%EC%85%985&sort=LOW_PRICE',NULL,NULL,'승재홍','K4i2vg8ADv0U5aiOG4i6gA==','ONGOING','REJECT','3463207627'),(18,'XMZ+zOiCE6C+HQ1OGZFCpZktPDysGvhPMgTOaZf4dW5YSY8c/rUeRSAK54tl5hml','kjsT+jBJ0ULLDpHUK1Q/LTzvt0c1kblD+nd18MAxHNA=','2024-05-17 16:53:39.343978','2024-05-21',47,380000,'컨설턴트님 감사합니다','색상 : 화이트','RqkVsCgSs00xIzPMUaLbhw==','https://gdimg.gmarket.co.kr/3605603964/still/600?ver=1714542921','https://item.gmarket.co.kr/Item?goodscode=3605603964&GoodsSale=Y&jaehuid=200001169&NaPm=ct%3Dlwadi54w%7Cci%3D9bf4da273ad13124f1941177f37d9bf83fe7dfae%7Ctr%3Dslct%7Csn%3D24%7Chk%3Dbe33c33f3fc6bddc1faddbc1ebd1b8c249408522','닌텐도 스위치 OLED 화이트 S_B',373090,'승재홍','K4i2vg8ADv0U5aiOG4i6gA==','ONGOING','APPROVE','3463207627');
/*!40000 ALTER TABLE `funding` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-17 20:10:33
